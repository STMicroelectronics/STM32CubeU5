/**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U5xx devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                      www.st.com/SLA0044
  *
  ****************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32U5xx 
  devices by MDK-ARM v5.25 and laters.

  Running the "Keil.STM32U5xx_DFP.1.0.5.pack" adds the following:
  ==============================================================
  
  1. Part numbers for  :
   - Product line with 2MB Flash size: STM32U575xI/U585xI
   - Product line with 1MB Flash size: STM32U575xG
   
  2. Automatic STM32U5 flash algorithm selection
     STM32U575I-EVAL dedicated connection with OSPI external loader support
		 
  3. SVD file for STM32U5


  How to use:
  ==========
  * Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
  You can download pack from keil web site @ www.keil.com
 
  * Double Clic on  "Keil.STM32U5xx_DFP.1.0.5.pack" in order to install this pack in the Keil install 
  directory.


******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE***************************