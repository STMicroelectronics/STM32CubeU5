  **
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U5xx devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32U5xx 
  devices by EWARM8 and laters.


   1. If you have already installed an STM32U57x-58x patch before, you can remove it by running 
      Uninstall_Patch.bat (run as administrator).

  2. Running the "EWARMv8_STM32U57x-58x_V1.4.exe" SIGNED patch adds the following:
  ================================================================================
    - Product line with 2MB Flash size: STM32U575xI/U585xI
    - Product line with 1MB Flash size: STM32U575xG
    - Automatic internal Flash loader selection
    - STM32U575I-EV  dedicated connection with OSPI2 (0x70000000) external loader support
    - B-U585I-IOT02A dedicated connection with OSPI2 (0x70000000) external loader support
    - STM32U575 and STM3285 SVD files 


 PS: when using external loader on EWARM, please unselect the verify from the debug menu

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
 You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32U57x-58x_V1.4.exe" as administrator at EWARM install directory.
 EWARM Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \". 



	



