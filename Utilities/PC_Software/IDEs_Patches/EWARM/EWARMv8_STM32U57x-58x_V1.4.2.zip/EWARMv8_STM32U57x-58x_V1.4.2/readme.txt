  **
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U57x-58x devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ************************************************************************************************************

  Package general purpose:
  ======================================================================================================================
	These packages contains the needed files to be installed in order to support STM32U57x-58x  devices by EWARM8 and laters.

	We inform you that this package is suitable for internal & external use.
	EWARMv8_STM32U57x-58x_V1.4.2.exe has been digitally signed by STMicroelectronics.
  

  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed:
  ======================================================================================================================
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
  
	 - Product line with 2MB Flash size: STM32U575xI/U585xI
     - Product line with 1MB Flash size: STM32U575xG
     - Automatic internal Flash loader selection
     - STM32U575I-EV  dedicated connection with OSPI2 (0x70000000) external loader support
     - B-U585I-IOT02A dedicated connection with OSPI2 (0x70000000) external loader support
	
	3. The following SVD files will be added:
	 - STM32U575 & STM32U585 v1r7.
	 
 PS: - when using external loader on EWARM, please unselect the verify from the debug menu. The flashloader contains a verify API using CheckSum.
	 - Make sure to set STLINK frequency to 12MHZ to get a better performance.	

  How to use:
 =======================================================================================================================
 * Before installing the files mentioned above, you need to have EWARM v8.xx.x or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32U57x-58x_V1.4.2.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   
 
 
 SVD files ReleaseNotes:
 ======================================================================================================================
	=======================================================
	STM32U5 SVD release note
	=======================================================
	V1.0   First release: adding support to STM32U5 devices
	V1.1   Second release: adding support to STM32U5-512k/2M/4M
	V1.2   Update in SVD files for interrupts and EXTI
	V1.3   Adding support for STM32U5Fx/Gx - 4M
	V1.4   Update in DBGMCU_IDCODE
	V1.5   Update with RM0456-Rev 5
	
	=======================================================
	STM32U585_v1r7:     Update 
	=======================================================
	Update according to Cut 3.3
	=======================================================
	STM32U575_v1r7:     Update 
	=======================================================
	Update according to Cut 3.3
