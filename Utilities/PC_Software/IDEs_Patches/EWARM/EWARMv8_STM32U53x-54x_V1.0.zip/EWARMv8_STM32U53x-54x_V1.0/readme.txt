  **
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U5xx devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32U5xx 
  devices by EWARM8 and laters.

  1. If you have already installed an STM32U53x-54x patch before, you can remove it by running 
     Uninstall_Patch.bat (run as administrator).
 
  2. Running the "EWARMv8_STM32U53x-54x_V1.0.exe" SIGNED patch adds the following:
  ================================================================================
    - Product line with 512KB Flash size: STM32U535xE/U545xE
    - Product line with 256KB Flash size: STM32U535xC
    - Product line with 128KB Flash size: STM32U535xB
    - Automatic internal Flash loader selection
    - STM32U535 & STM32U545 SVD files 


 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
 You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32U53x-54x_V1.0.exe" as administrator at EWARM install directory.
 EWARM Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \". 
 Please change it manually if you have EWARM installed at a different location.


	



