  **
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U5Fx-5Gx devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************

  These packages contains the needed files to be installed in order to support STM32U5Fx-5Gx 
  devices by EWARM8 and laters.
   

   Running the "EWARMv8_STM32U5Fx-5Gx_V1.0.0.exe" adds the following:
   ===================================================================
  
 - Part numbers with 4MB Flash size :STM32U5F9NJ/U5F9BJ/U5F9ZJ/U5F9VJ/U5F7VJ/U5G7VJ/U5G9NJ/U5G9BJ/U5G9ZJ/U5G9VJ
 - Part numbers with 2MB Flash size :STM32U5F9VI/U5F9ZI/U5F7VI
 - Automatic STM32U5Fx/Gx flash algorithm selection
 - ITM/SWO script for U5Fx/Gx
 - STM32U5Fx and STM32U5Gx SVD files 

  PS: when using external loader on EWARM, please unselect the verify from the debug men
 
 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
   You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32U5Fx-5Gx_V1.0.0.exe"  as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \". 





