  **
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U5Fx-5Gx devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ************************************************************************************************************

  Package general purpose:
  ======================================================================================================================
	These packages contains the needed files to be installed in order to support STM32U5Fx-5Gx  devices by EWARM8 and laters.

	We inform you that this package is suitable for internal & external use.
	EWARMv8_STM32U5Fx-5Gx_V1.0.1.exe has been digitally signed by STMicroelectronics.
  

  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed:
  ======================================================================================================================
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
  
	 - Part numbers with 4MB Flash size :STM32U5F9NJ/U5F9BJ/U5F9ZJ/U5F9VJ/U5F7VJ/U5G7VJ/U5G9NJ/U5G9BJ/U5G9ZJ/U5G9VJ
	 - Part numbers with 2MB Flash size :STM32U5F9VI/U5F9ZI/U5F7VI
	 - Automatic STM32U5Fx/Gx flash algorithm selection
	
	3. The following SVD files will be added:
	 - STM32U5Fx & STM32U5Gx v1r1.
	 
 PS: - when using external loader on EWARM, please unselect the verify from the debug menu. The flashloader contains a verify API using CheckSum.
	 - Make sure to set STLINK frequency to 12MHZ to get a better performance.	

  How to use:
 =======================================================================================================================
 * Before installing the files mentioned above, you need to have EWARM v8.xx.x or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32U5Fx-5Gx_V1.0.1.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   
 
 
 SVD files ReleaseNotes:
 ======================================================================================================================
	=======================================================
	STM32U5 SVD release note
	=======================================================
	V1.0   First release: adding support to STM32U5 devices
	V1.1   Second release: adding support to STM32U5-512k/2M/4M
	V1.2   Update in SVD files for interrupts and EXTI
	V1.3   Adding support for STM32U5Fx/Gx - 4M
	V1.4   Update in DBGMCU_IDCODE
	V1.5   Update with RM0456-Rev 5