  **
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U59x-5Ax devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************

  These packages contains the needed files to be installed in order to support STM32U59x-5Ax 
  devices by EWARM8 and laters.

  1. If you have already installed an STM32U59x-5Ax patch before, you can remove it by running 
  Uninstall_Patch.bat (run as administrator).

  2. Running the "EWARMv8_STM32U59x-5Ax_V1.2.exe" SIGNED patch adds the following:
   ===============================================================================
  
 - Part numbers with 4MB Flash size :STM32U595ZJ/STM32U5A5ZJ/STM32U599NJ/STM32U599BJ/STM32U5A9NJ/STM32U5A9BJ
 - Part numbers with 2MB Flash size :STM32U595AI/STM32U595QI/STM32U595RI/STM32U595VI/STM32U595ZI/STM32U599NI/STM32U599VI/STM32U599ZI
 - Automatic STM32U59 flash algorithm selection
 - STM32U599J-DK dedicated connection with OSPI external loader support  
 - STM32U599J-DK dedicated connection with eMMC external loader support  
 - STM32U599,STM32U595,STM32U5A9,STM32U5A5 SVD files 

 
 PS: when using external loader on EWARM, please unselect the verify from the debug menu

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
 You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32U59x-5Ax_V1.2.exe"  as administrator on EWARM install directory.
Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \". 







	



